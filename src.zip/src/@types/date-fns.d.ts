declare module 'date-fns';

declare module 'date-fns/locale' {
    const de: any; // Ou o tipo apropriado para o locale 'de'
    const en: any; // Ou o tipo apropriado para o locale 'en'
    // Adicione outras declarações de locale conforme necessário
  }