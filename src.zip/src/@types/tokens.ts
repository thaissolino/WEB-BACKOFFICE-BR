export interface Caixa {
  id: string;
  name: string;
  description: string;
  createdAt: string; // ou `Date` se você for converter no front-end
  updatedAt: string; // ou `Date`
}
