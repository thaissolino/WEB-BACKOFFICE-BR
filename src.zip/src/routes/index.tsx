// import { Routes, Route } from "react-router-dom";
// import Dashboard from "../pages/dashboard";
// import Team from "../pages/team";
// import Invoices from "../pages/invoices";
// import Contacts from "../pages/contacts";
// import FormRoom from "../pages/form-room";
// import FormUser from "../pages/form-user";
// import FormGroup from "../pages/form-group";

// const Router: React.FC = () => (
//   <Routes>
//     <Route path="/" element={<Dashboard />} />
//     <Route path="/team" element={<Team />} />
//     <Route path="/contacts" element={<Contacts />} />
//     <Route path="/invoices" element={<Invoices />} />
//     <Route path="/create-form-group" element={<FormGroup />} /> 
//     <Route path="/create-form-room" element={<FormRoom />} /> 
//     <Route path="/create-form-user" element={<FormUser />} /> 
//   </Routes>
// );

// export default Router;
